package com.orienit.kalyan.project.mr.learnings;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

public class CSVReaderWriter {
	public static void main(String[] args) throws IOException {
		CSVFormat csvFileFormat1 = CSVFormat.DEFAULT.withDelimiter(':');
		FileReader fileReader = new FileReader("/etc/passwd");
		CSVParser csvFileParser = new CSVParser(fileReader, csvFileFormat1);

		CSVFormat csvFileFormat2 = CSVFormat.DEFAULT.withDelimiter(',');
		FileWriter fileWriter = new FileWriter("/tmp/abc.csv");
		CSVPrinter csvFilePrinter = new CSVPrinter(fileWriter, csvFileFormat2);

		List<CSVRecord> csvRecords = csvFileParser.getRecords();
		for (int i = 1; i < csvRecords.size(); i++) {
			CSVRecord record = csvRecords.get(i);

			String f1 = record.get(0);
			String f2 = record.get(1);
			String f3 = record.get(2);

			List list = new ArrayList();
			list.add(f1);
			list.add(f2);
			list.add(f3);

			csvFilePrinter.printRecord(list);
			System.out.println(f1 + "\t" + f2 + "\t" + f3);
		}

		fileReader.close();
		csvFileParser.close();

		fileWriter.flush();
		fileWriter.close();
		csvFilePrinter.close();
	}
}
