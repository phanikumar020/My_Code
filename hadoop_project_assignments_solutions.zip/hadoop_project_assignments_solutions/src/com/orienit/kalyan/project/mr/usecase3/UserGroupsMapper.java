package com.orienit.kalyan.project.mr.usecase3;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;

public class UserGroupsMapper extends Mapper<LongWritable, Text, Text, NullWritable> {
	private MultipleOutputs<Text, NullWritable> mos;

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		mos = new MultipleOutputs<Text, NullWritable>(context);
	}

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		// Read the line
		String line = value.toString();

		// Split the line into fields
		String[] fields = line.split("::");

		// get the age from fields
		int age = Integer.parseInt(fields[2]);

		Text data = new Text(line.replaceAll("::", "\t"));

		if (age >= 1 && age <= 20) {
			mos.write("group1", data, NullWritable.get());
		} else if (age >= 21 && age <= 40) {
			mos.write("group2", data, NullWritable.get());
		} else if (age >= 41) {
			mos.write("group3", data, NullWritable.get());
		}
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		mos.close();
	}
}
