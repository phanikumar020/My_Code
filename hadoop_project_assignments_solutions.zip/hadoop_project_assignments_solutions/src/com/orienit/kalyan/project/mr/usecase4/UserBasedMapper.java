package com.orienit.kalyan.project.mr.usecase4;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;

public class UserBasedMapper extends Mapper<LongWritable, Text, Text, NullWritable> {
	private MultipleOutputs<Text, NullWritable> mos;

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		mos = new MultipleOutputs<Text, NullWritable>(context);
	}

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		// Read the line
		String line = value.toString();

		// Split the line into fields
		String[] fields = line.split("::");

		// get the age from fields
		int age = Integer.parseInt(fields[2]);

		// get the occupation from fields
		int occupation = Integer.parseInt(fields[3]);

		// get the gender from fields
		String gender = fields[1];

		Text data = new Text(line.replaceAll("::", "\t"));

		if (age >= 25 && age <= 40) {
			if (occupation == 12) {
				mos.write(data, NullWritable.get(), gender + "/Programmer/users");
			} else if (occupation == 15) {
				mos.write(data, NullWritable.get(), gender + "/Scientist/users");
			}
		}
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		mos.close();
	}
}
