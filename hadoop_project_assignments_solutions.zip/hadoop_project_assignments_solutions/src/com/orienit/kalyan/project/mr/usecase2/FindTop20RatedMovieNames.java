package com.orienit.kalyan.project.mr.usecase2;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.util.ToolRunner;

public class FindTop20RatedMovieNames {
	public static void main(String[] args) throws Exception {
		String ratings = args[0];
		String movies = args[1];
		String limit = args[2];
		String output = args[3];

		String movieidcountrating = "/tmp/movieidcountrating";
		String top20ratedmovieids = "/tmp/top20ratedmovieids";
		String top20ratedmovieidsfile = "/tmp/top20ratedmovieids/part-r-00000";

		Configuration conf = new Configuration();
		conf.setInt("limit", 20);

		int status1 = ToolRunner.run(conf, new MovieIdCountRatingJob(), new String[] { ratings, movieidcountrating });
		System.out.println("Job Status1: " + status1);

		int status2 = ToolRunner.run(conf, new Top20RatedMovieIdsJob(), new String[] { movieidcountrating, top20ratedmovieids, limit });
		System.out.println("Job Status2: " + status2);

		int status3 = ToolRunner.run(conf, new MovieNameCountRatingJob(), new String[] { movies, top20ratedmovieidsfile, output });
		System.out.println("Job Status3: " + status3);

	}
}
