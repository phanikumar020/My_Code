package com.orienit.kalyan.project.mr.usecase2;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Top20RatedMovieIdsMapper extends Mapper<LongWritable, Text, DoubleWritable, Text> {
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		// Read the line
		String line = value.toString();

		// Split the line into fields
		String[] fields = line.split("\t");

		// get the movieid from key
		double avg = Double.parseDouble(fields[1]);

		// Assign count to movieid
		context.write(new DoubleWritable(avg), value);
	}
}
