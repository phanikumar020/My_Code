package com.orienit.kalyan.project.mr.learnings;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

public class CSVWriterReader {
	public static void main(String[] args) throws IOException {

		CSVFormat csvFileFormat2 = CSVFormat.DEFAULT.withDelimiter(',');
		FileWriter fileWriter = new FileWriter("/tmp/abc.csv");
		CSVPrinter csvFilePrinter = new CSVPrinter(fileWriter, csvFileFormat2);

		for (int i = 1; i < 5; i++) {
			List list = new ArrayList();
			list.add("aaaa,1111");
			list.add("xxxx,2222");
			list.add("dddd:333");
			
			csvFilePrinter.printRecord(list);
			
		}

		fileWriter.flush();
		fileWriter.close();
		csvFilePrinter.close();

		CSVFormat csvFileFormat1 = CSVFormat.DEFAULT.withDelimiter(',');
		FileReader fileReader = new FileReader("/tmp/abc.csv");
		CSVParser csvFileParser = new CSVParser(fileReader, csvFileFormat1);

		List<CSVRecord> csvRecords = csvFileParser.getRecords();
		for (int i = 1; i < csvRecords.size(); i++) {
			CSVRecord record = csvRecords.get(i);

			String f1 = record.get(0);
			String f2 = record.get(1);
			String f3 = record.get(2);

			System.out.println(f1 + "\t" + f2 + "\t" + f3);
		}

		fileReader.close();
		csvFileParser.close();

	}
}
