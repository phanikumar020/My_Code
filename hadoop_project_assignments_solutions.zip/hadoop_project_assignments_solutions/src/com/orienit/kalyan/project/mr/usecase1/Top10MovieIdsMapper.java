package com.orienit.kalyan.project.mr.usecase1;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Top10MovieIdsMapper extends Mapper<Text, Text, LongWritable, LongWritable> {
	@Override
	protected void map(Text key, Text value, Context context) throws IOException, InterruptedException {
		// get the movieid from key
		long movieid = Long.parseLong(key.toString());

		// get the count from value
		long count = Long.parseLong(value.toString());

		// Assign count to movieid
		context.write(new LongWritable(count), new LongWritable(movieid));
	}
}
