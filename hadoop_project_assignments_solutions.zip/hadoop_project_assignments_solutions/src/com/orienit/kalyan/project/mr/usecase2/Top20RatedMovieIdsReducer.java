package com.orienit.kalyan.project.mr.usecase2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Top20RatedMovieIdsReducer extends Reducer<DoubleWritable, Text, Text, NullWritable> {
	int limit;
	int count;

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		Configuration conf = context.getConfiguration();
		limit = Integer.parseInt(conf.get("limit"));
		count = 0;
	}

	@Override
	protected void reduce(DoubleWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		if (count < limit) {
			for (Text value : values) {
				if (count < limit) {
					context.write(value, NullWritable.get());
					count++;
				}
			}
		}
	}
}
