package com.orienit.kalyan.project.mr.usecase1;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class Top10MovieIdsReducer extends Reducer<LongWritable, LongWritable, LongWritable, LongWritable> {
	int limit;
	int count;

	@Override
	protected void setup(Context context) throws IOException, InterruptedException {
		Configuration conf = context.getConfiguration();
		limit = Integer.parseInt(conf.get("limit"));
		count = 0;
	}

	@Override
	protected void reduce(LongWritable key, Iterable<LongWritable> values, Context context) throws IOException, InterruptedException {
		if (count < limit) {
			for (LongWritable value : values) {
				if (count < limit) {
					context.write(value, key);
					count++;
				}
			}
		}
	}
}
