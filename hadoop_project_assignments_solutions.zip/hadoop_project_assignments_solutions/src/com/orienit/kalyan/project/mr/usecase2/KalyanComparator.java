package com.orienit.kalyan.project.mr.usecase2;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.RawComparator;
import org.apache.hadoop.io.WritableComparator;

public class KalyanComparator implements RawComparator<DoubleWritable> {

	@Override
	public int compare(DoubleWritable left, DoubleWritable right) {
		return (int) (right.get() - left.get());
	}

	@Override
	public int compare(byte[] b1, int s1, int l1, byte[] b2, int s2, int l2) {
		return WritableComparator.compareBytes(b2, s2, l2, b1, s1, l1);
	}

}
