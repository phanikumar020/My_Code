package com.orienit.kalyan.project.mr.usecase2;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MovieIdCountRatingMapper extends Mapper<LongWritable, Text, LongWritable, LongWritable> {
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		// Read the line
		String line = value.toString();

		// Split the line into fields
		String[] fields = line.split("::");

		// get the movieid from fields
		long movieid = Long.parseLong(fields[1]);
		
		// get the rating from fields
		long rating = Long.parseLong(fields[2]);

		// Assign rating to movieid
		context.write(new LongWritable(movieid), new LongWritable(rating));
	}
}
