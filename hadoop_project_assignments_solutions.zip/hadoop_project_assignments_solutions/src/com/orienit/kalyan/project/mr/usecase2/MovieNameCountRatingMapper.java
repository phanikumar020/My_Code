package com.orienit.kalyan.project.mr.usecase2;

import java.net.URI;
import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MovieNameCountRatingMapper extends Mapper<LongWritable, Text, Text, NullWritable> {

	private FSDataInputStream stream;
	Map<Double, String> result;

	@Override
	protected void setup(Context context) throws java.io.IOException, InterruptedException {
		Configuration conf = context.getConfiguration();
		URI[] uris = DistributedCache.getCacheFiles(conf);
		FileSystem fs = FileSystem.get(uris[0], conf);
		stream = fs.open(new Path(uris[0]));
		result = new TreeMap<Double, String>(new KalyanComparator());
	};

	@Override
	protected void map(LongWritable key, Text value, Context context) throws java.io.IOException, InterruptedException {
		stream.seek(0);

		// Read the line
		String inputLine = value.toString();

		// Split the line into lfields
		String[] lfields = inputLine.split("::");

		// get the movieid, title, genres from fields
		String movieid = lfields[0];
		String title = lfields[1];

		String dcLine;
		while ((dcLine = stream.readLine()) != null) {
			// Split the line into fields
			String[] rfields = dcLine.split("\t");

			// get the movieid, avg, count from rfields
			String rmovieid = rfields[0];
			String ravg = rfields[1];
			String rcount = rfields[2];

			// inner join
			if (movieid.equals(rmovieid)) {
				String row = title + ":" + ravg + ":" + rcount;
				result.put(Double.parseDouble(ravg), row);
				break;
			}
		}
	};

	@Override
	protected void cleanup(Context context) throws java.io.IOException, InterruptedException {
		stream.close();
		for (Entry<Double, String> record : result.entrySet()) {
			context.write(new Text(record.getValue()), NullWritable.get());
		}
	};

	class KalyanComparator implements Comparator<Double> {
		@Override
		public int compare(Double o1, Double o2) {
			return o2.compareTo(o1);
		}
	}
}