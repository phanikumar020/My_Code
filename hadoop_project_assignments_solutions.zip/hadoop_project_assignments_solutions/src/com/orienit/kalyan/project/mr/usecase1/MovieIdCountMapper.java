package com.orienit.kalyan.project.mr.usecase1;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MovieIdCountMapper extends Mapper<LongWritable, Text, LongWritable, LongWritable> {
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		// Read the line
		String line = value.toString();

		// Split the line into fields
		String[] fields = line.split("::");

		// get the movieid from fields
		long movieid = Long.parseLong(fields[1]);

		// Assign count(1) to each movieid
		context.write(new LongWritable(movieid), new LongWritable(1));
	}
}
