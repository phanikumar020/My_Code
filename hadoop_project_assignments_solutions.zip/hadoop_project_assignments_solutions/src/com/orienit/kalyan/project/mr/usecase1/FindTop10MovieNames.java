package com.orienit.kalyan.project.mr.usecase1;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.util.ToolRunner;

public class FindTop10MovieNames {
	public static void main(String[] args) throws Exception {
		String ratings = args[0];
		String movies = args[1];
		String limit = args[2];
		String output = args[3];

		String movieidcount = "/tmp/movieidcount";
		String top10movieids = "/tmp/top10movieids";
		String top10movieidsfile = "/tmp/top10movieids/part-r-00000";

		Configuration conf = new Configuration();
		conf.setInt("limit", 10);

		int status1 = ToolRunner.run(conf, new MovieIdCountJob(), new String[] { ratings, movieidcount });
		System.out.println("Job Status1: " + status1);

		int status2 = ToolRunner.run(conf, new Top10MovieIdsJob(), new String[] { movieidcount, top10movieids, limit });
		System.out.println("Job Status2: " + status2);

		int status3 = ToolRunner.run(conf, new MovieNameCountJob(), new String[] { movies, top10movieidsfile, output });
		System.out.println("Job Status3: " + status3);

	}
}
