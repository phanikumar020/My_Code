import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.sql.*;
import javax.swing.table.*;
import java.awt.event.*;

class database extends JFrame 
{
	

	JPanel jp1=new JPanel();
	JScrollPane jsp;
	int flag=1;
	String routername;
    JTable jrta;
	RouterTable rrt;
	String peername,filename,ipaddress;
	ResultSet rs;
	Connection c;
	Statement st;
	Object header[]={"PeerName","FileName","IPAddress"};
	int i=0;
	
    
	public database(Vector v1)throws Exception
	{
		
		jp1.setLayout(new BorderLayout());
		 jrta=new JTable();
         rrt=new RouterTable();
		 rrt.setColumnIdentifiers(header);
		 jrta.setModel(rrt);
		jsp=new JScrollPane(jrta);
		jp1.add(jsp,BorderLayout.CENTER);
		add(jp1);
		
		 

		setSize(500,300);
		setVisible(true);
		setTitle("Routing Table");
		
		
		
		
		

		
		Vector v=new Vector();
		//Vector v=v1;
		//rrt.addRow(v);
		
		 //c=new system().database();
		
		//st=c.createStatement();
		//rs=st.executeQuery("select * from peerdetails");
		while(i<v1.size())
		{
			
            peername=(String)v1.elementAt(i);
			//System.out.println(peername+"\t");
			v.addElement(peername);

			filename=(String)v1.elementAt(i+1);
			//System.out.println(filename+"\t");
			v.addElement(filename);
			
			ipaddress=(String)v1.elementAt(i+2);
			//System.out.println(ipaddress+"\t");
			v.addElement(ipaddress);
			i=i+3;
			
			rrt.addRow(v);
			v=new Vector();
			
			
		}

		/*for(int i=0;i<=v.size();i++)
		{


		}*/
	
	
	
	
}
class RouterTable extends DefaultTableModel
	{
		RouterTable()
		{
		}
	}

}