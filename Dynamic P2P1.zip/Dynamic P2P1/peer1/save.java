import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import org.gui.JDirectoryDialog; // External Tool for Jfile Chooser

class save extends JFrame implements ActionListener
{
	JPanel p1=new JPanel();
	JLabel la1=new JLabel();
	JTextArea jta=new JTextArea();
	JLabel jt=new JLabel();
    JButton save=new JButton("Save");
	JButton cancel=new JButton("Cancel");
	JScrollPane jsp=new JScrollPane(jta);
	byte d1[];
	String fname;
		//int flag=1;
public	JDirectoryDialog directoryDialog; 
String desdir="";
File f5;
	save(int flag,byte d[],String f)throws Exception
	{
        p1.setLayout(null);
		if(flag==0)
		{
	    p1.add(jt);
		p1.add(la1);
		p1.add(save);
		p1.add(cancel);
		jt.setBounds(50,50,350,25);
		la1.setBounds(50,100,260,390);
		save.setBounds(75,400,100,25);
		cancel.setBounds(200,400,100,25);
	
		}
		else
		{
		p1.add(jsp);
		p1.add(save);
		p1.add(cancel);
		jsp.setBounds(5,5,390,350);
		save.setBounds(75,400,100,25);
		cancel.setBounds(200,400,100,25);
		}
		add(p1);
		d1=d;
		fname=f;
		save.addActionListener(this);
		cancel.addActionListener(this);
		//la1.setColor(255,255,255);
		setSize(400,500);
        setVisible(true);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent e)
	{
		try
		{
			if(e.getSource()==save)
			{ if(directoryDialog == null)
				{
					directoryDialog = new JDirectoryDialog(save.this);
				}
				if(directoryDialog.showDirectoryDialog())
				{
					File destFile = directoryDialog.getSelectedFolder();
					desdir=destFile.getAbsolutePath();
					
				}
				//f2.delete();
				 f5=new File(desdir,fname); 
				 if(f5.exists())
					 JOptionPane.showMessageDialog(null,"File Already Exist");

				else
				{
				FileOutputStream fo=new FileOutputStream(f5,true);
				//System.out.println("d:"+new String(d1));
				fo.write(d1);
				}
//System.out.println("d:"+d1);
				
			}
			if(e.getSource()==cancel)
			{
		     dispose();
			}

		}
		catch (Exception e1)
		{
			e1.printStackTrace();
		}

		
	}
	
}
