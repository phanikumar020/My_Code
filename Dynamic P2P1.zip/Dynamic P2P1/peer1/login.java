  import java.awt.*; 
 import java.awt.event.*; 
 import javax.swing.*; 
 import java.net.*;
 /** 
  * Summary description for login 
  * 
  */ 
 public class login extends JFrame 
 { 
	 public static ServerSocket ssoc1;

	public static Socket sousoc1,ss1;
 	// Variables declaration 
 	private JLabel userlabel; 
 	private JLabel jLabel2; 
 	private JLabel jLabel3; 
 	private JLabel jLabel4; 
 	private JLabel jLabel5; 
 	private JTextField userfield; 
 	private JPasswordField jPasswordField1; 
 	private JButton login; 
 	private JButton clear; 
 	private JPanel contentPane; 
 	// End of variables declaration 
static   peer pe1;
  public static String username="";
  static int n;
 	public login() throws Exception
 	{ 
 		super(); 
 		initializeComponent(); 
 		// 
 		// TODO: Add any constructor code after initializeComponent call 
 		// 
         
 		this.setVisible(true); 
 	} 
  
 	/** 
 	 * This method is called from within the constructor to initialize the form. 
 	 * WARNING: Do NOT modify this code. The content of this method is always regenerated 
 	 * by the Windows Form Designer. Otherwise, retrieving design might not work properly. 
 	 * Tip: If you must revise this method, please backup this GUI file for JFrameBuilder 
 	 * to retrieve your design properly in future, before revising this method. 
 	 */ 
 	private void initializeComponent() 
 	{ 
 		userlabel = new JLabel(); 
 		jLabel2 = new JLabel(); 
 		jLabel3 = new JLabel(); 
 		jLabel4 = new JLabel(); 
 		jLabel5 = new JLabel(); 
 		userfield = new JTextField(); 
 		jPasswordField1 = new JPasswordField(); 
 		login = new JButton(); 
 		clear = new JButton(); 
 		contentPane = (JPanel)this.getContentPane(); 
  
 		// 
 		// userlabel 
 		// 
 		userlabel.setHorizontalAlignment(SwingConstants.CENTER); 
 		userlabel.setHorizontalTextPosition(SwingConstants.CENTER); 
 		userlabel.setText("UserName"); 
 		// 
 		
 	
 	
 
 		
 		jLabel3.setIcon(new ImageIcon("submit.jpg"));
 		// 
 		// userfield 
 		// 
 		userfield.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				userfield_actionPerformed(e); 
 			} 
  
 		}); 
 		// 
 		// jPasswordField1 
 		// 
 		jPasswordField1.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				jPasswordField1_actionPerformed(e); 
 			} 
  
 		}); 
 		// 
 		// login 
 		// 
 		login.setText("Login"); 
 		login.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				login_actionPerformed(e); 
 			} 
  
 		}); 
 		// 
 		// clear 
 		// 
 		clear.setText("Clear"); 
 		clear.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				clear_actionPerformed(e); 
 			} 
  
 		}); 
 		// 
 		// contentPane 
 		// 
 		contentPane.setLayout(null); 
 		contentPane.setBackground(new Color(125, 155, 225)); 
 		addComponent(contentPane, userlabel, 76,100,70,18); 
 		//addComponent(contentPane, jLabel2, 76,208,70,18); 
 		addComponent(contentPane, jLabel3, 120,-50,499,200); 
 		//addComponent(contentPane, jLabel4, -1,200,492,30); 
 		addComponent(contentPane, jLabel5, -1,203,495,31); 
 		addComponent(contentPane, userfield, 202,100,100,25); 
 		//addComponent(contentPane, jPasswordField1, 203,206,100,25); 
 		addComponent(contentPane, login, 50,170,100,28); 
 		addComponent(contentPane, clear, 170,170,100,28); 
 		// 
 		// login 
 		// 
 		this.setTitle("Peer Login"); 
 		this.setLocation(new Point(19, 37)); 
 		this.setSize(new Dimension(400, 250)); 
 		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 
 		this.setResizable(false); 
 	} 
  
 	/** Add Component Without a Layout Manager (Absolute Positioning) */ 
 	private void addComponent(Container container,Component c,int x,int y,int width,int height) 
 	{ 
 		c.setBounds(x,y,width,height); 
 		container.add(c); 
 	} 
  
 	// 
 	// TODO: Add any appropriate code in the following Event Handling Methods 
 	// 
 	private void userfield_actionPerformed(ActionEvent e) 
 	{ 
 		System.out.println("\nuserfield_actionPerformed(ActionEvent e) called."); 
 		// TODO: Add any handling code here 
  
 	} 
  
 	private void jPasswordField1_actionPerformed(ActionEvent e) 
 	{ 
 		System.out.println("\njPasswordField1_actionPerformed(ActionEvent e) called."); 
 		// TODO: Add any handling code here 
  
 	} 
  
 	private void login_actionPerformed(ActionEvent e) 
 	{ 
		try
		{
			username=userfield.getText();
			

System.out.println("server port:"+n);
		
		pe1.user(username);
	
		peerUI pf1=new peerUI(username);

        dispose();
		
			
			
		}
		catch (Exception e1)
		{
		}
		
 		System.out.println("\nlogin_actionPerformed(ActionEvent e) called."); 
 		// TODO: Add any handling code here 
  
 	} 
  
 	private void clear_actionPerformed(ActionEvent e) 
 	{ 
 		System.out.println("\nclear_actionPerformed(ActionEvent e) called."); 
 		
  userfield.setText("");
 	} 
  
 	// 
 	// TODO: Add any method code to meet your needs in the following area 
 	// 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
   
  
 //============================= Testing ================================// 
 //=                                                                    =// 
 //= The following main method is just for testing this class you built.=// 
 //= After testing,you may simply delete it.                            =// 
 //======================================================================// 
 	public static void main(String[] args) 
 	{ 
 		JFrame.setDefaultLookAndFeelDecorated(true); 
 		JDialog.setDefaultLookAndFeelDecorated(true); 
 		try 
 		{ 
 pe1=new peer();
		new login(); 
		
		n=pe1.connection();
		System.out.println("server port:"+n);
ssoc1=new ServerSocket(n);
		while(true)
		{
		ss1=ssoc1.accept();

		pe1.receive1();
		}
			
	/*	n=pe1.connection(username);
		System.out.println("server port:"+n);
ssoc1=new ServerSocket(n);
		//pf1=new peerUI(name);
		
        
		while(true)
		{
		ss1=ssoc1.accept();

		pe1.receive1();
		}*/
 			//UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel"); 
 		} 
 		catch (Exception ex) 
 		{ 
 			System.out.println("Failed loading L&F: "); 
 			System.out.println(ex); 
 		} 
 		
		
		
		
		
		
	
 	} 
 //= End of Testing = 
  
  
 } 
  
 