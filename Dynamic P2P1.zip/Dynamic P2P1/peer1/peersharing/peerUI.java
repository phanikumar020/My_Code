                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            /****************************************************************/
/*                      peerUI	                            */
/*                                                              */
/****************************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;
import javax.swing.table.*;
import org.gui.JDirectoryDialog; // External Tool for Jfile Chooser
import java.net.*;

/**
 * Summary description for peerUI
 *
 */
public class peerUI extends JFrame 
{
	// Variables declaration
	public JPanel contentPane;
	//-----
	public JLabel filename;
	public JLabel nodename;
	public JLabel connode;
	public JLabel desname;
	static JTextField filefield;
	static JLabel nodefield;
	public JTextField desfield;
	public JTextArea jTextArea1;
	public JScrollPane jScrollPane2;
	public JButton browse;
	public JButton send,upload;
	public JButton clear;
	public JButton cancel;
	public JButton RouTable;
	public JPanel jPanel1;
	public JPanel jPanel5;
	public static Socket soc;//,ss1;
    ObjectInputStream oi;
    ObjectOutputStream oo;
	//-----
	public JLabel label;
	public JLabel label1,label2;
	public JPanel jPanel2;
	sysname sys=new sysname();
	String  network="";
	
	public ButtonGroup bg;
	public static JTable jtab;
	public static  RouterTable rd;
	Object header[]={};
	JTabbedPane tb=new JTabbedPane();
	
	public JScrollPane jscp;
	//-----
	// End of variables declaration
 public	JDirectoryDialog directoryDialog; 

FileDialog fl;
String desdir,file,flname;
File f;
peer pe1=new peer();
String username;
JProgressBar jpb=new JProgressBar(JProgressBar.HORIZONTAL);
	javax.swing.Timer timer;
	public peerUI(String name)throws Exception
	{
		super();
	
		initializeComponent(name);
		network=sys.orgin();
		//
		// TODO: Add any constructor code after initializeComponent call
		//
       pe1.ownfiles1(name);
       
		this.setVisible(true);

	}

	
	public void initializeComponent(String name)throws Exception
	{
		contentPane = (JPanel)this.getContentPane();
		//-----
		filename = new JLabel();
		nodename = new JLabel();
		connode = new JLabel();
		desname = new JLabel();
		filefield = new JTextField();
		nodefield = new JLabel();
		desfield = new JTextField();
		jTextArea1 = new JTextArea();
		jScrollPane2 = new JScrollPane();
		browse = new JButton();
		send = new JButton();
		upload = new JButton();
		clear = new JButton();
		cancel = new JButton();
		RouTable=new JButton();
		jPanel1 = new JPanel();
		jPanel5 = new JPanel();
		//-----
		label = new JLabel();
		label1 = new JLabel();
		label2 = new JLabel();
		jPanel2 = new JPanel();
		
		
		//-----
		jtab=new JTable();
		rd=new RouterTable();
		rd.setColumnIdentifiers(header);
		jtab.setModel(rd);
          jscp=new JScrollPane(jtab);
             fl=new FileDialog(this,"Load",FileDialog.LOAD);
		//
		// contentPane
		//
		

		jpb.setValue(0);
		username=name;
		
		contentPane.setLayout(null);
		//JSplitPane tb=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,jPanel5,jPanel1);

		tb.addTab(" Frame",jPanel1);


addComponent(contentPane,tb, -6,240,550,320);
		addComponent(contentPane, jPanel2, -9,0,500,240);

		//
		// filename
		//
		filename.setText("File");
		//
		// nodename
		//
		nodename.setText(" Peer");
		//
		// connode
		//
		
		//
		// desname
		//
		desname.setText("Choose File");
		//
		// filefield
		//
		
		filefield.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				filefield_actionPerformed(e);
			}

		});
		//
		// nodefield
		//
		//nodefield.setForeground(new Color(240,120,60));
		/*nodefield.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				nodefield_actionPerformed(e);
			}

		});*/
		//
		// desfield
		//
		//
		// jTextArea1
		//
		
		//
		// jScrollPane2
		//
		jScrollPane2.setViewportView(jTextArea1);
		//
		// browse
		//
		browse.setText("Browse");
		browse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
 			{ 
				try
				{
					//label2.setIcon(new ImageIcon("merling.gif"));
					
					fl.setVisible(true);
					flname=fl.getFile();
					f=new File(flname);
					//f=;
					String path=fl.getDirectory();
					file=path+f;
					//File f2=new File(file);
					System.out.println("path:"+path);
					System.out.println("path:"+file);
					desfield.setText(file);
					//label2.setIcon(new ImageIcon(" "));
					//label2.setIcon(new ImageIcon("merling.gif"));
				}
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
				
 		 } 
  
 		}); 
		//});
		//
		// send
		//
		
		send.setText("Search");
		send.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) 
 		{ 
			String s1="";
			try
			{
				if(send.getText()=="Search")
				{
				pe1.send();
			   label2.setIcon(new ImageIcon("merling.gif"));
			   String file =filefield.getText();
				JOptionPane.showMessageDialog(null,"Searching RoutingTable");
				
				String sdp=pe1.searchdb(1,file);
				pe1.searchpeer(sdp,username);
				label2.setIcon(new ImageIcon(" "));
					
					if(!file.equals(""))
					{
						System.out.println("testsearch");
						soc=new Socket(network,2111);
						oo=new ObjectOutputStream(soc.getOutputStream());
						System.out.println("testsearch1");

						//String ia=InetAddress.getLocalHost().getHostName();
						oo.writeObject("Incremental");
						oo.writeObject(file);
						oo.writeObject(username);
					}

				}
				
					
				}
			
				catch (Exception e1)
				{
					e1.printStackTrace();
				
				}
				
		}
				});
				
	

//send.setText("Search");
		
			
		//
		// clear
		//
		clear.setText("Share");
		clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
 			{ 
				try
				{
					JOptionPane.showMessageDialog(null,"Sharing File");
					String sdp=pe1.searchdb(0,flname);
					nodefield.setText(username);
			   		FileInputStream fin=new FileInputStream(file);
					byte content[]=new byte[fin.available()];
					fin.read(content);
					//System.out.println("File Content:"+new String(content));
					f=new File(".","//peersharing/"+flname);
					if(f.exists())
					{
						pe1.upload1(0,flname,username);
						JOptionPane.showMessageDialog(null,"File Already Exist");
					}
					else
					{
						pe1.upload1(1,flname,username);
						FileOutputStream fout=new FileOutputStream(f);
						fout.write(content);
					}

					if(!flname.equals(""))
					{
						System.out.println("test");
						soc=new Socket(network,2111);
						oo=new ObjectOutputStream(soc.getOutputStream());
						System.out.println("test1");

						String ia=InetAddress.getLocalHost().getHostName();
						oo.writeObject("Routing Table");
						oo.writeObject(flname);
						oo.writeObject(ia);
						oo.writeObject(username);
					}
			   }
		   	   catch (Exception sh)
			   {
			   }
			 }
   		}); 
		cancel.setText("Leave");
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
 			{ 
				try
				{
					new peer();
					pe1.exit(username);
					 System.exit(0);
				
				}
				catch (Exception e2)
				{
					e2.printStackTrace();
				}
				
			}
  
 		}); 

		RouTable.setText("RouTable");
		RouTable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
 			{ 
				try
				{
					System.out.println("Now you clicked Routing Table Button");
					soc=new Socket(network,2111);
					oo=new ObjectOutputStream(soc.getOutputStream());
					//System.out.println("test1");

					//String ia=InetAddress.getLocalHost().getHostName();
					oo.writeObject("RetriveTable");
					oi=new ObjectInputStream(soc.getInputStream());
					Vector v1=(Vector)oi.readObject();
					if(v1.size()!=0)
					{
						System.out.println("RouTableVector :::: "+v1);
						database dbase=new database(v1);
						
					}
					else
					{

					}
					

					

				}
				catch (Exception e1)
				{
					e1.printStackTrace();
				}
				
 		 } 
  
 		}); 
		
		
		jPanel1.setLayout(null);
		jPanel5.setLayout(new BorderLayout());
		jPanel5.add(jscp,BorderLayout.CENTER);
		jPanel1.setBackground(new Color(255, 255,255));
	    addComponent(jPanel1, filename, 120,58,100,18);
		addComponent(jPanel1, nodename, 120,108,100,18);
		addComponent(jPanel1, connode, 359,22,100,28);
		addComponent(jPanel1, desname, 100,158,120,18);
		addComponent(jPanel1, filefield, 210,58,100,22);
		addComponent(jPanel1, nodefield, 210,108,100,22);
		addComponent(jPanel1, desfield, 210,158,100,22);
		//addComponent(jPanel1, jScrollPane2, 350,47,200,100);
		
		addComponent(jPanel1, RouTable, 325,120,90,28);
		addComponent(jPanel1, browse, 325,158,83,28);
		addComponent(jPanel1, send, 75,200,83,28);
		
		addComponent(jPanel1, clear, 200,200,83,28);
		addComponent(jPanel1, cancel, 325,200,83,28);
		addComponent(jPanel1, label2, 5,20,100,200);
		addComponent(jPanel1, label, 20,100,100,200);

		//
		// label
		//
		//
		// label1
		//
		
		label1.setIcon(new ImageIcon("home.jpg"));
		
		//
		// jPanel2
		//
		jPanel2.setLayout(null);
		jPanel2.setBackground(new Color(255,255,255));
		//addComponent(jPanel2, label, 200,0,150,59);
		addComponent(jPanel2, label1, 20,0,500,240);
		//
		// peerUI
		//
       
		
		//jTextArea1.append("n");
		
		this.setTitle(name);
		this.setLocation(new Point(0, 0));
		this.setSize(new Dimension(500, 550));
		this.setResizable(false);
		fl.setLocation(800,800);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		
		
	}

	/** Add Component Without a Layout Manager (Absolute Positioning) */
	
	public void addComponent(Container container,Component c,int x,int y,int width,int height)
	{
		c.setBounds(x,y,width,height);
		container.add(c);
	}

	//
	// TODO: Add any appropriate code in the following Event Handling Methods
	//
	public void filefield_actionPerformed(ActionEvent e)
	{
		System.out.println("\nfilefield_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	public void nodefield_actionPerformed(ActionEvent e)
	{
		System.out.println("\nnodefield_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	public void browse_actionPerformed(ActionEvent e)
	{
		System.out.println("\nbrowse_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	//
	// TODO: Add any method code to meet your needs in the following area
	//
  

	public static void adddata(Vector v)throws Exception
	{
		rd.addRow(v);
	}
	
	public static int rowdelete()throws Exception
	{
		int rc=jtab.getRowCount();
		int q=0;
		if(rc!=0)
		{
		DefaultTableModel model =
  (DefaultTableModel)jtab.getModel();
model.removeRow(0);
q=1;
		}
		return q;
	}
	



class RouterTable extends DefaultTableModel
{
	RouterTable()
	{
	}
} 
}
