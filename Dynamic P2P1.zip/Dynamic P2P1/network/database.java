import java.sql.*;
import java.util.*;
class database 
{
	ResultSet rs;
	Connection con;
	Statement st;
	Vector v;
	public Statement dbcon()throws Exception
	{
         Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		 con=DriverManager.getConnection("jdbc:odbc:net");
		 st=con.createStatement();
		return st;
	}
	public void insert(String s)throws Exception
	{
      st.executeUpdate(s);
	}
	public void delete(String s1)throws Exception
	{
      st.executeUpdate(s1);
	}


	public Vector select(String s)throws Exception
	{
		 v=new Vector();
     rs= st.executeQuery(s);
	 while(rs.next())
		{
		
		 String q1=rs.getString(1);
		  String q2=rs.getString(2);
		   String q3=rs.getString(3);
         v.add(q1);
		 v.add(q2);
		 v.add(q3);
		 
		}
		return v;
	}

	public boolean check(String s)throws Exception
	{
     rs= st.executeQuery(s);
	 if(rs.next())
		{
		 return true;
		}
		return false;
	}
}