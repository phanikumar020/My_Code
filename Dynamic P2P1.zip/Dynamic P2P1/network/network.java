 import java.sql.*;
 import java.io.*;
 import java.net.*;
 import java.util.*;
 /** 
  * Summary description for network 
  * 
  */ 
 public class network
 { 
 	
	private database db;
	ResultSet rs;
	Connection cs;
	Statement st;
	Vector v,v1;
	static ServerSocket sersoc;
	static Socket soc;
	ObjectInputStream dis;
	ObjectOutputStream dos;
	InputStream is;
	OutputStream os;
 	// End of variables declaration 
    String n="",ip="",s,s1,name;
    static network m;
    int port=4444,na;
 	public network()throws Exception
 	{ 
 		super(); 
		db = new database();
		st=db.dbcon();
		 s="delete  from peerconnection";
		 s1="delete from RoutingTable";
  		 db.delete(s);
		 db.delete(s1);
 		//initializeComponent();
 		// 
 		// TODO: Add any constructor code after initializeComponent call 
 		// 
  
 		//this.setVisible(true); 
 	 } 
  
 	
  
 	// 
 	// TODO: Add any method code to meet your needs in the following area 


 	// 
	public void rec()throws Exception
	 {
    
     
	  dis=new ObjectInputStream(soc.getInputStream());
	  String nname=(String)dis.readObject();
	  System.out.println("recived:"+nname);
	
	  if(nname.equals("peers"))
	  {
		v=new Vector();
		s="select * from peerconnection";
		v=db.select(s);
		System.out.println("v:"+v);
		dos=new ObjectOutputStream(soc.getOutputStream());
		dos.writeObject(v);
 
	 }
	 else if(nname.equals("exit"))
	 {
		dis=new ObjectInputStream(soc.getInputStream());
		String nname1=(String)dis.readObject();
		System.out.println("exit:"+nname1);
		 v=new Vector();
		s="delete from peerconnection where peerno='"+nname1+"'";
		//s="update peerconnection set status='false' where peerno='"+nname1+"'";
		db.delete(s);
 	 }
	else if(nname.equals("user"))
	 {
		dis=new ObjectInputStream(soc.getInputStream());
		String nname2=(String)dis.readObject();
		String array[]=nname2.split("&");
		System.out.println("nname2:"+nname2);
		System.out.println("array[0]:"+array[0]);
		System.out.println("array[1]:"+array[1]);
		int q=Integer.parseInt(array[1]);
		System.out.println("q:"+q);
		s="select * from peerconnection where peerno='"+array[0]+"'";
		if(db.check(s))
		{
			s="update peerconnection set status='true' where peerno='"+array[0]+"'";
			db.insert(s);
		 }
		 else
		 {
		
 			s="update peerconnection set  peerno='"+array[0]+"'where port='"+q+"'";
			System.out.println("q:"+q);
			db.insert(s);
			System.out.println("q:"+q);
		}
	  }
	  else if(nname.equals("Routing Table"))
	  {
			//dis=new ObjectInputStream(soc.getInputStream());
			String FileName=(String)dis.readObject();
			String SystemName=(String)dis.readObject();
			String NodeName=(String)dis.readObject();

		    if(!FileName.equals(""))
		    {
				 Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				 Connection con=DriverManager.getConnection("jdbc:odbc:net");
				 Statement st=con.createStatement();
				 ResultSet rs=st.executeQuery("Select * from RoutingTable where FileName='"+FileName+"'");
				 if(rs.next())
				 {
					 //System.out.println("FileName already in DataBase");

				 }
				 else
				 {
					String s1="insert into RoutingTable values('"+NodeName+"','"+FileName+"','"+SystemName+"')";
					db.insert(s1);
					System.out.println("FileName   :::::: "+FileName);
					System.out.println("SystemName :::::: "+SystemName);
					System.out.println("NodeName   :::::: "+NodeName);
				 }
		    }

		}
		 else if(nname.equals("RetriveTable"))
		{
			 Vector vec=new Vector();
			 try
			 {
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				Connection con=DriverManager.getConnection("jdbc:odbc:net");
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("Select * from RoutingTable");
				while(rs.next())
				{
					vec.add(rs.getString(1).trim());
					vec.add(rs.getString(2).trim());
					vec.add(rs.getString(3).trim());
				}
			 	}
				catch (Exception e)
				{
					System.out.println(e);
				}
				dos=new ObjectOutputStream(soc.getOutputStream());
				if(vec.size()!=0)
				{
					dos.writeObject(vec);
				}
				else
				{
					dos.writeObject("NoRecords");
				}

		}
		else if(nname.equals("Incremental"))
	    {
			int i=1;
			//dis=new ObjectInputStream(soc.getInputStream());
			String FileName=(String)dis.readObject();
			//String SystemName=(String)dis.readObject();
			String VisitNode=(String)dis.readObject();
			System.out.println("Search Node :::::: "+VisitNode);

		    if(!FileName.equals(""))
		    {
				 Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				 Connection con=DriverManager.getConnection("jdbc:odbc:net");
				 Statement st=con.createStatement();
				 ResultSet rs=st.executeQuery("Select * from RoutingTable where FileName='"+FileName+"'");
				 if(rs.next())
				 {
					 System.out.println("1");
					/*System.out.println(rs.getString(1));
					System.out.println(rs.getString(2));
					System.out.println(rs.getString(3));
					System.out.println(rs.getString(4));
					System.out.println(rs.getString(5));*/
					String NodeName=rs.getString(1).trim();
					String Fname=rs.getString(2).trim();
					String Vnode=rs.getString(4).trim();
					int Vcount=rs.getInt(5);
					System.out.println("2"+Vcount);

					System.out.println("Vnode ::::: "+Vnode);
					System.out.println("Visitnode ::::: "+VisitNode);
					
					if(VisitNode.equals(Vnode))
					 {
						Vcount=Vcount+i;
						System.out.println("3"+Vcount);
						//String s="update RoutingTable set VisitNode='"+NodeName+"' where FileName='"+FileName+"'";
						String s1="update RoutingTable set VisitCount="+Vcount+" where FileName='"+FileName+"'";
						//db.insert(s);
						db.insert(s1);
					 }
					 else
					 {
						// if(!FileName.equals(Fname) !! !)
						//{
								System.out.println("4"+Vcount);
								String s="update RoutingTable set VisitNode='"+VisitNode+"' where FileName='"+FileName+"'";
								String s1="update RoutingTable set VisitCount="+i+" where FileName='"+FileName+"'";
								db.insert(s);
								db.insert(s1);
						// }
					 }

				 }
				 else
				 {
					/*String s1="insert into RoutingTable values('"+NodeName+"','"+FileName+"','"+SystemName+"','Vnode',0)";
					db.insert(s1);
					System.out.println("FileName   :::::: "+FileName);
					System.out.println("SystemName :::::: "+SystemName);*/
					System.out.println("FileName Not Found");
				 }
		    }

		}
		else
		{

			dos=new ObjectOutputStream(soc.getOutputStream());
			port=port+1;
			//na=na+1;
			//name="peer"+String.valueOf(na);
			String p=String.valueOf(port);
			System.out.println("p:"+p);

			s="Insert into peerconnection values('','"+nname+"','"+port+"','on')";
			db.insert(s);
			dos.writeObject(p);
			System.out.println("send");
		}
	 }
	 
	public void cleardb()
	{
		try
		{
			//st = db.dbcon();
			s="delete from peerconnection";
  			db.delete(s);
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
   
  
 //============================= Testing ================================// 
 //=                                                                    =// 
 //= The following main method is just for testing this class you built.=// 
 //= After testing,you may simply delete it.                            =// 
 //======================================================================// 
 	public static void main(String[] args) 
 	{ 
 		
 		try 
 		{ 
			
			sersoc=new ServerSocket(2111);
			m=new network();
			while(true)
			{
				soc=sersoc.accept();
				m.rec();
			} 
 			//UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel"); 
 		} 
 		catch (Exception ex) 
 		{ 
 			System.out.println("Failed loading L&F: "); 
 			System.out.println(ex); 
 		} 
 		
 	} 
 //= End of Testing = 
  
} 