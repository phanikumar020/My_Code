import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import org.gui.JDirectoryDialog; // External Tool for Jfile Chooser
public class peer extends JFrame implements Runnable
{
	//public static ServerSocket ssoc1;

   public static Socket sousoc1;//,ss1;
   ObjectInputStream oi,oi1;
   ObjectOutputStream oo,oo1;
   static Thread th;
   int t,p,k,i;
   String data1=new String();
   String rec1="",port;
   static String name;
   ResultSet rs,rs1;
   Connection c;
   Statement s,s1;
   Vector v1;
   Vector f,f1;
   String ia="";
   byte bd[];
   String filelist[];
   String peerdetails[][];
   public static peerUI pf1;
   public JDirectoryDialog directoryDialog; 
String desdir="",network;
save dp;
File f2,f5;
String username,u1;
login u;
sysname sys=new sysname();

Vector fil=new Vector();
//constructor

   public peer()throws Exception
	{
	   dbaseconnect1();
	   
	  s.executeUpdate("delete from RoutingTable1");
	  network=sys.orgin();
	   th=new Thread(this);
         th.start();
	  
	}
//database connection

	public void dbaseconnect1()throws Exception
	{
		 
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		c=DriverManager.getConnection("jdbc:odbc:searchpeer1");
		s=c.createStatement();
       s1=c.createStatement(); 
	}
	
	// own files

	public void ownfiles1(String username)throws Exception
	{
		File fi=new File(".","//peersharing");
		filelist=fi.list();
		v1=new Vector();
		for(int i=0;i<filelist.length;i++)
		{
			s.executeUpdate("Insert into RoutingTable1 values('"+username+"','"+filelist[i]+"','0')");
		}
    }

//peername

	public String peername(String username)throws Exception
	{
		return username;
	}


//create connection for peer

public int connection()throws Exception
{
	sousoc1=new Socket(network,2111);
	oo=new ObjectOutputStream(sousoc1.getOutputStream());
	 

	 ia=InetAddress.getLocalHost().getHostName();
	 oo.writeObject(ia);
	   
	 oi=new ObjectInputStream(sousoc1.getInputStream());
	 port=(String)oi.readObject();
	
	 System.out.println("port:"+port);
	
	 p=Integer.parseInt(port);
	 return p;

}

//send username

public void user(String username)throws Exception
{
	sousoc1=new Socket(network,2111);
	oo=new ObjectOutputStream(sousoc1.getOutputStream());
	oo.writeObject("user");
	System.out.println("1");
	oo=new ObjectOutputStream(sousoc1.getOutputStream());
	oo.writeObject(username+"&"+String.valueOf(p));
	System.out.println("username:"+username);
}

//send method

public void send()throws Exception
{
	f1=new Vector();
	sousoc1=new Socket(network,2111);
	oo=new ObjectOutputStream(sousoc1.getOutputStream());
	 
	oo.writeObject("peers");
	oi=new ObjectInputStream(sousoc1.getInputStream());
	f1=(Vector)oi.readObject();
	System.out.println("f1:"+f1);
	System.out.println("f1.size():"+f1.size()/3);
	peerdetails=new String[f1.size()/3][3];
	int j=0;
	for(int i=0;i<f1.size()/3;i++)
	{
		System.out.println("f1:"+i+f1.elementAt(i));
		System.out.println("un:"+username);
		
		peerdetails[i][0]=String.valueOf(f1.elementAt(j));
		peerdetails[i][1]=String.valueOf(f1.elementAt(j+1));
		peerdetails[i][2]=String.valueOf(f1.elementAt(j+2));
		j=j+3;
	}
	for(int i=0;i<f1.size()/3;i++)
	{
		System.out.println((i+1)+":"+peerdetails[i][0]);
		System.out.println((i+1)+":"+peerdetails[i][1]);
	    System.out.println((i+1)+":"+peerdetails[i][2]);
	}
}
	


//exit
	public void exit(String u1)throws Exception
	{
		sousoc1=new Socket(network,2111);
		oo=new ObjectOutputStream(sousoc1.getOutputStream());
	 
	 
	  
	   oo.writeObject("exit");
	   oo=new ObjectOutputStream(sousoc1.getOutputStream());
	 
	 
	 System.out.println("exit:"+username);
	 System.out.println("exit1:"+u1);
	   oo.writeObject(u1);
	}



// search database

	public String searchdb(int i,String file)throws Exception
	{
		
	rs=s.executeQuery("select PeerName from RoutingTable1 where SharingFiles = '"+file+"'");
		String peername="";
		while(rs.next())
		{
        peername=rs.getString(1);
		System.out.println("peer:"+peername);
		}
		
if(!peername.equals(""))
{
rs=s.executeQuery("select Visit from RoutingTable1 where SharingFiles='"+file+"'");
if(rs.next())
{
int c=Integer.parseInt(rs.getString(1));
c=c+1;
if(c>2)
	{
	System.out.println("peer:"+peername);
	rs1=s1.executeQuery("select * from RoutingTable1 where SharingFiles = '"+file+"'");
	System.out.println("1");
		Vector z=new Vector();
		
		while(rs1.next())
		{
			
       z.addElement(rs1.getString(1));
	  
       z.addElement(rs1.getString(2));
       z.addElement(rs1.getString(3));
		//System.out.println("peer:"+peername);
		}
		fil.addElement(file);
peerUI.adddata(z);
JOptionPane.showMessageDialog(null,"Most User Interest File");
	}
if(i==1)
s.executeUpdate("Update RoutingTable1 set Visit='"+c+"' where SharingFiles='"+file+"'");
else
	s.executeUpdate("Update RoutingTable1 set Visit='0' where SharingFiles='"+file+"'");

System.out.println("2");

}
else
{
s.executeQuery("select from RoutingTable1");
while(true)
			{

s.executeUpdate("Update  RoutingTable1 set PeerName='"+peername+"' where PeerName='"+peername+"'");
			//System.out.println("RT:"+peer);
			}
}


	}
	
		return peername;
	}


//folder search

	public int folder1()throws Exception
	{
		int flag=0;
		File f=new File(".","//peersharing");
		filelist=f.list();
		v1=new Vector();
		for(int i=0;i<filelist.length;i++)
		{
			
			System.out.println("files"+filelist[i]);
			System.out.println("files"+rec1);
			if(rec1.equals(filelist[i]))
				{
		System.out.println("files"+rec1);
 File f1=new File(".","//peersharing//"+rec1);
     FileInputStream fi=new FileInputStream(f1);
	      
	     bd=new byte[fi.available()];
		 fi.read(bd);
		 System.out.println("bd:"+new String(bd));
	
             System.out.println("bd:"+bd.toString());
           System.out.println("fi:"+fi.read());
			 flag=1;
			 
				}
		v1.add(filelist[i]);
		
		}
		
		return flag;
	}


// receiver

	public void receive1()throws Exception
	{
  oi1=new ObjectInputStream(login.ss1.getInputStream());
   rec1=(String)oi1.readObject();
  
   System.out.println("recived:"+rec1);
   int f=folder1();
   System.out.println("flag:"+f);
   oo1=new ObjectOutputStream(login.ss1.getOutputStream());
     if(f==1)
		{
		
     oo1.writeObject(v1);
	 oo1=new ObjectOutputStream(login.ss1.getOutputStream());

	 oo1.writeObject(bd);
		}
	 else
		{
		 v1=new Vector();
		 v1.add("No");
       oo1.writeObject(v1);
		}
	}


// search peer

public void searchpeer(String sdp,String username)throws Exception
	{
String s1="No";
 System.out.println("length:"+peerdetails.length);
  System.out.println("username:"+username);
  int z=0;
	for(int i=0;i<peerdetails.length;i++)
		{
		if(sdp.equals(username))
			{
JOptionPane.showMessageDialog(null,"File required is in OwnShare");	
z=1;
              }
	else if(sdp.equals(peerdetails[i][0]) && !peerdetails[i][0].equals(username))
			{
		int port =Integer.parseInt(peerdetails[i][2]);
		s1=senddata1(1,peerdetails[i][0],peerdetails[i][1],port);;
         JOptionPane.showMessageDialog(null,"File required is in "+peerdetails[i][0]);
		 z=1;
			}
			System.out.println("i-------------------->:"+i);
		}
			if(z==0)
			{
             for(i=0;i<peerdetails.length;i++)
		{
				 	System.out.println("i-------------------->>:"+i);
	if(s1.equals("No"))
			{
		int port =Integer.parseInt(peerdetails[i][2]);
		s1=senddata1(0,peerdetails[i][0],peerdetails[i][1],port);;
		System.out.println("i-------------------->>:"+i);
		if(!s1.equals("No"))
			{
         JOptionPane.showMessageDialog(null,"File required is in "+peerdetails[i][0]);
			z=1;
			System.out.println("i-------------------->>:"+i);
			}
			System.out.println("i-------------------->>:"+i);
			}
		}
			if(z==0)
			{
         JOptionPane.showMessageDialog(null,"File Not in Share or Peer not Share  ");
          
			}
			
			
		
	}
	}

	
// send data

	public String senddata1(int t,String peer,String ipaddress,int port)throws Exception
	{
		
dbaseconnect1();
	 String location="";
	 System.out.println("ip:"+ipaddress);
	 System.out.println("port:"+port);
		 sousoc1=new Socket(ipaddress,port);
		  
	   oo=new ObjectOutputStream(sousoc1.getOutputStream());
	 
	  String filename=peerUI.filefield.getText();
	   oo.writeObject(filename);
	   oi=new ObjectInputStream(sousoc1.getInputStream());
	   f=(Vector)oi.readObject();
	   location=String.valueOf(f.elementAt(0));
	   String q=String.valueOf(f);
	   System.out.println("recived:"+q);
	   
	   System.out.println("location:"+location);
	if(f.elementAt(0).equals("No"))
		System.out.println("f:"+f.elementAt(0));
	   else
		{
		   if(t==1)
			{
			  //peer=peer.split("+");
			   System.out.println("RT:"+peer);
			   for(int i=0;i<f.size();i++)
			{

s.executeUpdate("Update  RoutingTable1 set PeerName='"+peer+"' where PeerName='"+peer+"'");
			//System.out.println("RT:"+peer);
			}
for(int i=0;i<f.size();i++)
			{

s.executeUpdate("Update  RoutingTable1 set PeerName='"+peer+"' where PeerName='"+peer+"'");
			//System.out.println("RT:"+peer);
			}
            update(f,peer);
			update(f,peer);
			}
		   else
			{
 for(int i=0;i<f.size();i++)
			{

s.executeUpdate("Insert into RoutingTable1 values('"+peer+"','"+f.elementAt(i)+"','0') ");
			}
s.executeUpdate("Update  RoutingTable1 set Visit='1' where SharingFiles='"+filename+"'");
		update(f,peer);
        update(f,peer);
			JOptionPane.showMessageDialog(null,peer+" has the file" );
			}
			//JOptionPane.showMessageDialog(null,peer+" has the file" );
			oi=new ObjectInputStream(sousoc1.getInputStream());
	   byte d[]=(byte[])oi.readObject();
	   String fc=new String(d);
	
	int flag=1;
	peerUI.nodefield.setText(peer);
	System.out.println("file:"+filename);
	System.out.println("index:"+filename.indexOf(".txt"));
	int i=filename.length();
						String exten=filename.substring(i-4,i);
						System.out.println("exten:"+exten);
	if(exten.equals(".txt")||exten.equals(".doc")||exten.equals("java"))
			{
		 dp=new save(1,d,filename);
		 dp.jta.setText(fc);
//System.out.println("content:"+fc);
			}
		else if(exten.equals(".pdf"))
			{
		 dp=new save(1,d,filename);
		 dp.jta.setText(filename+"  file Opened  ");

			}
			
			else
			{
dp=new save(0,d,filename);
	 dp.jt.setText(filename+"  file Opened  ");
			
dp.la1.setIcon(new ImageIcon(d));

			}
     
    
		}
	
	return location ;
	}


//update

public void update(Vector f,String peer)throws Exception
	{
for(int i=0;i<f.size();i++)
			{

s.executeUpdate("Update  RoutingTable1 set PeerName='"+peer+"' where PeerName='"+peer+"'");
			//System.out.println("RT:"+peer);
			}
	}
	public void upload1(int i,String filename,String user)throws Exception
	{
		if(i==1)
s.executeUpdate("Insert into RoutingTable1 values('"+user+"','"+filename+"','0')");
		else
s.executeUpdate("Update  RoutingTable1 set PeerName='"+user+"' where PeerName='"+user+"'");

	}
	
// Thread run

public void run()
	{
	while(true)
		{
		try
		{
			
			System.out.println("1");
			Thread.sleep(50000);
			int q=peerUI.rowdelete();
			if(q==1)
			{
					s.executeUpdate("Update RoutingTable1 set Visit='0' where SharingFiles='"+fil.elementAt(k)+"'");
					System.out.println("k---------------->>"+k);
		            k++;
			}

		}
		catch (Exception ex)
		{
System.out.println(ex);
		}
		

		}
	}
	
   
	public static void main(String[] args) 
 	{ 
 		JFrame.setDefaultLookAndFeelDecorated(true); 
 		JDialog.setDefaultLookAndFeelDecorated(true); 
 		try 
 		{ 
 //new peer();
		//new login(); 
			peerUI pf1=new peerUI("hai");

		//n=pe1.connection();
		//System.out.println("server port:"+n);
//ssoc1=new ServerSocket(1111);
		
	/*	n=pe1.connection(username);
		System.out.println("server port:"+n);
ssoc1=new ServerSocket(n);
		//pf1=new peerUI(name);
		
        
		while(true)
		{
		ss1=ssoc1.accept();

		pe1.receive1();
		}*/
 			//UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel"); 
 		} 
 		catch (Exception ex) 
 		{ 
 			System.out.println("Failed loading L&F: "); 
 			System.out.println(ex); 
 		} 
 		
		
		
		
		
		
	
 	} 
}