-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 20, 2011 at 11:04 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ems_admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `adm_det`
--

CREATE TABLE IF NOT EXISTS `adm_det` (
  `adm_no` varchar(20) NOT NULL,
  `dept_id` varchar(20) NOT NULL,
  `cls_id` varchar(20) NOT NULL,
  `stu_fname` varchar(100) NOT NULL,
  `stu_lname` varchar(100) NOT NULL,
  PRIMARY KEY (`adm_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adm_det`
--

INSERT INTO `adm_det` (`adm_no`, `dept_id`, `cls_id`, `stu_fname`, `stu_lname`) VALUES
('65743', 'CSE', '07BCS', 'saravanakumar', 'gs'),
('876767', 'CSE', '07BCS', 'dinesh', 's'),
('87643', 'CSE', '07BCS', 'dinesh', 's'),
('94932', 'CSE', '07BCS', 'bharathraj', 'r'),
('1001', 'CSE', '10BCS', 'senthilnathan', 'k'),
('1002', 'CSE', '10BCS', 'dinesh', 's'),
('1003', 'CSE', '10BCS', 'dinesh', 'v'),
('1004', 'CSE', '10BCS', 'kavin', 'kc'),
('1005', 'CSE', '10BCS', 'kabilan', 'v'),
('1006', 'CSE', '10BCS', 'hari', 'jayanth'),
('1007', 'CSE', '10BCS', 'santhosh', 'k'),
('1008', 'CSE', '10BCS', 'saravana', 'gs'),
('1009', 'CSE', '10BCS', 'pradheep', 'kk'),
('1010', 'CSE', '10BCS', 'naveen', 'santhosh');

-- --------------------------------------------------------

--
-- Table structure for table `cls_reg`
--

CREATE TABLE IF NOT EXISTS `cls_reg` (
  `cls_id` varchar(20) NOT NULL,
  `dept_id` varchar(20) NOT NULL,
  `no_sem` varchar(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cls_reg`
--

INSERT INTO `cls_reg` (`cls_id`, `dept_id`, `no_sem`) VALUES
('07BCS', 'CSE', '8'),
('08BCS', 'CSE', '8'),
('09BCS', 'CSE', '8'),
('10BCS', 'CSE', '8');

-- --------------------------------------------------------

--
-- Table structure for table `dept_reg`
--

CREATE TABLE IF NOT EXISTS `dept_reg` (
  `dept_id` varchar(5) NOT NULL,
  `dept_name` varchar(100) NOT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dept_reg`
--

INSERT INTO `dept_reg` (`dept_id`, `dept_name`) VALUES
('CSE', 'Computer Science and Engineering'),
('ECE', 'Electronic and Communication Engineering'),
('eie', 'ghjgjh'),
('SAH', 'SCIENCE AND HUMANITIES');

-- --------------------------------------------------------

--
-- Table structure for table `elc_alloc`
--

CREATE TABLE IF NOT EXISTS `elc_alloc` (
  `cls_id` varchar(10) NOT NULL,
  `subj_id` varchar(50) NOT NULL,
  `stu_id` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elc_alloc`
--

INSERT INTO `elc_alloc` (`cls_id`, `subj_id`, `stu_id`) VALUES
('07BCS', 'U07CS201', '07BCS10'),
('07BCS', 'U07CS201', '07BCS11'),
('07BCS', 'U07CS201', '07BCS12'),
('07BCS', 'U07CS201', '07BCS13'),
('07BCS', 'U07CS201', '07BCS14'),
('07BCS', 'U07CS201', '07BCS15'),
('07BCS', 'U07CS201', '07BCS16'),
('07BCS', 'U07CS201', '07BCS17'),
('07BCS', 'U07CS201', '07BCS18'),
('07BCS', 'U07CS201', '07BCS19'),
('07BCS', 'U07CS201', '07BCS20'),
('07BCS', 'U07GE111', '07BCS01'),
('07BCS', 'U07GE111', '07BCS02'),
('07BCS', 'U07GE111', '07BCS04'),
('07BCS', 'U07GE111', '07BCS05'),
('07BCS', 'U07GE111', '07BCS06'),
('07BCS', 'U07GE111', '07BCS07'),
('07BCS', 'U07GE111', '07BCS08'),
('07BCS', 'U07GE111', '07BCS09'),
('07BCS', 'U07GE111', '07BCS10'),
('07BCS', 'U07GE111', '07BCS16'),
('07BCS', 'U07GE111', '07BCS17'),
('07BCS', 'U07GE111', '07BCS18'),
('07BCS', 'U07GE111', '07BCS19'),
('07BCS', 'U07GE111', '07BCS20');

-- --------------------------------------------------------

--
-- Table structure for table `ss_alloc`
--

CREATE TABLE IF NOT EXISTS `ss_alloc` (
  `cls_id` varchar(10) NOT NULL,
  `dept_id` varchar(10) NOT NULL,
  `sem_id` varchar(3) NOT NULL,
  `subj_id` varchar(50) NOT NULL,
  `stf_id` varchar(50) NOT NULL,
  `mode` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ss_alloc`
--

INSERT INTO `ss_alloc` (`cls_id`, `dept_id`, `sem_id`, `subj_id`, `stf_id`, `mode`) VALUES
('07BCS', 'CSE', '2', 'U07CS201', 'cse002', 'ELECTIVE'),
('07BCS', 'CSE', '8', 'U07GM111', 'cse002', 'ELCNOR'),
('07BCS', 'CSE', '8', 'U07GE111', 'cse002', 'ELECTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `staff_reg`
--

CREATE TABLE IF NOT EXISTS `staff_reg` (
  `staff_id` varchar(20) NOT NULL,
  `staff_name` varchar(100) NOT NULL,
  `desg` varchar(50) NOT NULL,
  `dept_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_reg`
--

INSERT INTO `staff_reg` (`staff_id`, `staff_name`, `desg`, `dept_id`) VALUES
('cse001', 'devaki', 'HOD', ''),
('cse002', 'm.s.hema', 'Professor', ''),
('cse5', 'sudhakar', 'Senior Lecturer', 'CSE'),
('cse9', 'sivan', 'Senior Lecturer', 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `stu_inf`
--

CREATE TABLE IF NOT EXISTS `stu_inf` (
  `stu_id` varchar(100) NOT NULL,
  `adm_no` varchar(100) NOT NULL,
  `stu_name` varchar(100) NOT NULL,
  `stu_cl_id` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stu_inf`
--

INSERT INTO `stu_inf` (`stu_id`, `adm_no`, `stu_name`, `stu_cl_id`) VALUES
('07BCS01', '879797', 'AARTHI', '07BCS'),
('10BCS2', '1008', 'saravana', '10BCS'),
('10BCS3', '1009', 'pradheep', '10BCS'),
('10BCS1', '1007', 'santhosh', '10BCS'),
('07BCS02', '645365437', 'ANANAD', '07BCS'),
('07BCS04', '7897987', 'ARUNKUMAR', '07BCS'),
('07BCS05', '987483', 'BAMA', '07BCS'),
('07BCS06', '987483', 'BHARATHRAJ', '07BCS'),
('07BCS07', '987483', 'BHARATHIDASAN', '07BCS'),
('07BCS08', '987483', 'BHUVANA', '07BCS'),
('07BCS09', '987483', 'DEEPIKA', '07BCS'),
('07BCS10', '987483', 'DINESH', '07BCS'),
('07BCS11', '987483', 'DINESH', '07BCS'),
('07BCS12', '987483', 'DINESH', '07BCS'),
('07BCS13', '987483', 'DIVYA', '07BCS'),
('07BCS14', '987483', 'GOWTHAM', '07BCS'),
('07BCS15', '987483', 'GOWTHAM', '07BCS'),
('07BCS16', '987483', 'GOWTHAM', '07BCS'),
('07BCS17', '987483', 'HARIJAYANTH', '07BCS'),
('07BCS18', '987483', 'HEMALATHA', '07BCS'),
('07BCS19', '987483', 'INDHUMATHI', '07BCS'),
('07BCS20', '987483', 'KABILAN', '07BCS'),
('07BCS22', '987483', 'KASTHURI', '07BCS'),
('07BCS23', '987483', 'KAVIN', '07BCS'),
('07BCS24', '987483', 'KAVYA', '07BCS'),
('07BCS25', '987483', 'LIDIYA', '07BCS'),
('07BCS26', '987483', 'PHANIKUMAR', '07BCS'),
('07BCS27', '987483', 'MADHANGANESH', '07BCS'),
('07BCS28', '987483', 'MANIMEKALA', '07BCS'),
('07BCS29', '987483', 'NATHIYA', '07BCS'),
('07BCS30', '987483', 'NAVEENSANTHOSH', '07BCS'),
('10BCS4', '1010', 'naveen', '10BCS'),
('10BCS5', '1006', 'hari', '10BCS'),
('10BCS6', '1005', 'kabilan', '10BCS'),
('10BCS7', '1002', 'dinesh', '10BCS'),
('10BCS8', '1003', 'dinesh', '10BCS'),
('10BCS9', '1004', 'kavin', '10BCS'),
('10BCS10', '1001', 'senthilnathan', '10BCS'),
('10BCS1', '1007', 'santhosh', '10BCS'),
('10BCS2', '1008', 'saravana', '10BCS'),
('10BCS3', '1009', 'pradheep', '10BCS'),
('10BCS4', '1010', 'naveen', '10BCS'),
('10BCS5', '1006', 'hari', '10BCS'),
('10BCS6', '1005', 'kabilan', '10BCS'),
('10BCS7', '1002', 'dinesh', '10BCS'),
('10BCS8', '1003', 'dinesh', '10BCS'),
('10BCS9', '1004', 'kavin', '10BCS'),
('10BCS10', '1001', 'senthilnathan', '10BCS');

-- --------------------------------------------------------

--
-- Table structure for table `stu_mark`
--

CREATE TABLE IF NOT EXISTS `stu_mark` (
  `year_id` varchar(20) NOT NULL,
  `stu_id` varchar(20) NOT NULL,
  `sub_id` varchar(20) NOT NULL,
  `sem_id` varchar(20) NOT NULL,
  `mark` int(3) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stu_mark`
--

INSERT INTO `stu_mark` (`year_id`, `stu_id`, `sub_id`, `sem_id`, `mark`) VALUES
('07BCS', '07BCS46', 'U07CY101', '1', 77),
('07BCS', '07BCS46', 'U07GE102', '1', 83),
('07BCS', '07BCS46', 'U07GE103', '1', 95),
('07BCS', '07BCS46', 'U07GE104', '1', 98),
('07BCS', '07BCS46', 'U07HS101', '1', 65),
('07BCS', '07BCS46', 'U07MA101', '1', 79),
('07BCS', '07BCS46', 'U07PH101', '1', 68),
('07BCS', '07BCS46', 'U07PH102', '1', 94),
('07BCS', '07BCS46', 'U07CY102', '1', 93),
('07BCS', '07BCS46', 'U07GE101', '1', 87),
('08BCS', '08BCS46', 'U08CY101', '1', 43),
('06BCS', '06BCS46', 'UOTYTDSG', '1', 78),
('07BCS', '07BCS47', 'dfhfkjdsh', '1', 78);

-- --------------------------------------------------------

--
-- Table structure for table `sub_reg`
--

CREATE TABLE IF NOT EXISTS `sub_reg` (
  `sub_id` varchar(20) NOT NULL,
  `sub_name` varchar(100) NOT NULL,
  `crd_pt` varchar(2) NOT NULL,
  `dept_id` varchar(20) NOT NULL,
  PRIMARY KEY (`sub_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sub_reg`
--

INSERT INTO `sub_reg` (`sub_id`, `sub_name`, `crd_pt`, `dept_id`) VALUES
('U07GE111', 'SQM', '4', 'CSE'),
('U07GM111', 'ADVANCED OPERATING SYSTEM', '2', 'CSE'),
('U07CS201', 'DATA STRUCTURE', '4', 'CSE'),
('U07GE102', 'FUNDAMENTALS OF COMPUTING', '3', 'SAH');

-- --------------------------------------------------------

--
-- Table structure for table `user_auth`
--

CREATE TABLE IF NOT EXISTS `user_auth` (
  `user_id` varchar(20) NOT NULL,
  `passwd` varchar(20) NOT NULL,
  `user_typ` varchar(20) NOT NULL,
  `status` varchar(3) NOT NULL DEFAULT '0',
  `uni_id` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_auth`
--

INSERT INTO `user_auth` (`user_id`, `passwd`, `user_typ`, `status`, `uni_id`) VALUES
('saravana', 'gss123', '1', '1', 'adm4646'),
('dinesh', 'din123', '1', '1', 'adm5555'),
('sartcse', 'sart', '2', '1', 'stf1324'),
('santhosh', 'san123', '1', '1', '07bcs43'),
('din', 'din123', '1', '1', '07bcs10'),
('gss46', 'gss123', '1', '1', 'adm1234'),
('sart', '123', '1', '1', '07bcs46'),
('kckavin', 'kckavin', '1', '1', '07bcs23'),
('navsan', 'navsan', '1', '1', '07bcs30'),
('karthi', 'rm', '1', '1', '0989879');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE IF NOT EXISTS `user_info` (
  `user_id` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `email`) VALUES
('santhosh', 'san@gmail.com'),
('gss46', 'sartcse@gmail.com'),
('din', 'abc@gmail.com'),
('sart', 'sartcse@gmail.com'),
('kckavin', 'kckavin24@gmail.com'),
('navsan', 'kct@gmail.com'),
('karthi', 'kdsajl@fajfds.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
